<?php
$hostname="localhost";
$database="Shopee";
$db_login="root";
$db_pass="";

$dlink = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");
mysql_select_db($database) or die("Could not select database");

if($_REQUEST['uname'] !=""){
   $query="insert into user(custname,address) values('".$_REQUEST['uname']."','".$_REQUEST['address']."')";
   $result = mysql_query($query) or die(mysql_error());
}
?>
<form action=register.php method=post>
Enter Name<input type=text name=uname><br>
Enter Address<input type=text name=address><br>
<input type=submit value=submit>
</form>