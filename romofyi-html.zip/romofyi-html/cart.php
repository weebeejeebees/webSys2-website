<?php 
$user_type = $_COOKIE['type'] ?? '';
include 'carty.php'; 
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>romofyi</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout footer_to90 fashion_page">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="header_top d_none1">
               <div class="container">
                  <div class="row">
                     <div class="col-md-4">
                        <ul class="conta_icon">
                           <li><a href="#"><img src="images/call.png" alt="#"/>Call us: 0126 - 922 - 0162</a> </li>
                        </ul>
                     </div>
                     <div class="col-md-4">
                        <ul class="social_icon">
                           <li> <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i>
                              </a>
                           </li>
                           <li> <a href="#"><i class="fa fa-twitter"></i></a></li>
                           <li> <a href="#"> <i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                           <li> <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i>
                              </a>
                           </li>
                        </ul>
                     </div>
                     <div class="col-md-4">
                        <div class="se_fonr1">
                           <form action="#" >
                              <div class="select-box">
                                 <label for="select-box1" class="label select-box1"><span class="label-desc">English</span> </label>
                                 <select id="select-box1" class="select">
                                    <option value="Choice 1">English</option>
                                    <option value="Choice 1">Falkla</option>
                                    <option value="Choice 2">Germa</option>
                                    <option value="Choice 3">Neverl</option>
                                 </select>
                              </div>
                           </form>
                           <span class="time_o"> Open hour: 8.00 - 18.00</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="header_midil">
               <div class="container">
                  <div class="row d_flex">
                     <div class="col-md-4">
                        <ul class="conta_icon d_none1">
                           <li><a href="#"><img src="images/email.png" alt="#"/> demo@gmail.com</a> </li>
                        </ul>
                     </div>
                     <div class="col-md-4">
                        <a class="logo" href="#"><img src="images/logo.png" alt="#"/></a>
                     </div>
                     <div class="col-md-4">
                        <ul class="right_icon d_none1">
                           <li><a href="#"><img src="images/shopping.png" alt="#"/></a> </li>
                           <a href="#" class="order">Order Now</a> 
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <div class="header_bottom">
               <div class="container">
                  <div class="row">
                     <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <nav class="navigation navbar navbar-expand-md navbar-dark ">
                           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                           <span class="navbar-toggler-icon"></span>
                           </button>
                           <div class="collapse navbar-collapse" id="navbarsExample04">
                              <ul class="navbar-nav mr-auto">
                                 <li class="nav-item ">
                                    <a class="nav-link" href="index.php">Home</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link" href="products.php">Products</a>
                                    <?php if ($user_type == 'customer'):?>
                                        <li class="nav-item"><a class="nav-link" href="myorders.php?cart=true"><i aria-hidden="true"></i><span>My Orders</span></a></li>
                                    <?php endif ?>
                              </ul>
                           </div>
                        </nav>
                     </div>
                     <div class="col-md-4">
                        <div class="search">
                           <form action="/action_page.php">
                              <input class="form_sea" type="text" placeholder="Search" name="search">
                              <button type="submit" class="seach_icon"><i class="fa fa-search"></i></button>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- end header inner -->
      <!-- fashion section -->
      <?php
        // * Cart page/view
        $to_cart = $_REQUEST['cart'] ?? false; // $to_cart = isset($_REQUEST['cart']) ? $_REQUEST['cart'] : false;
        if ($to_cart) { ?>
            <p style="font-size: x-large; font-weight: bold; text-align: center; margin: 100px;">CART</p>
            <div style="display: flex; justify-content: center; align-items: center;">
                <form action="cart.php?cart=true" method="post">
                    <table>
                        <!-- Cart header -->
                        <thead>
                            <tr>
                                <th colspan="2" style="padding-left: 70px; padding-right: 70px;"></th>
                                <th style="padding-left: 70px; padding-right: 70px;">Description</th>
                                <th style="padding-left: 70px; padding-right: 70px;">Name</th>
                                <th style="padding-left: 70px; padding-right: 70px;">Quantity</th>
                                <th style="padding-left: 70px; padding-right: 70px;">Total Price</th>
                                <th style="padding-left: 70px; padding-right: 70px;">Actions</th>
                            </tr>
                        </thead>
                        <!-- Carted products -->
                        <tbody>
                            <?php
                            $total_price = 0;
                            foreach ($products_cart as $id => $in_cart) {
                                $product_id = $in_cart[0];
                                $product_name = $in_cart[2];
                                $product_description = $in_cart[3];
                                $product_img = $in_cart[4];
                                $carted_quantity = $in_cart[7];
                                $product_price = $in_cart[6] * $carted_quantity;
                                $total_price += $product_price;
                                ?>
                                <tr>
                                    <td style="padding-left: 70px; padding-right: 70px; padding-bottom: 100px;">
                                        <input type="checkbox" name="cart_product[]" value=<?php echo $product_id ?>>
                                    </td>
                                    <td style="padding-left: 70px; padding-right: 70px; padding-bottom: 100px;">
                                        <img src="<?php echo $product_img ?>" alt="product">
                                    </td>
                                    <td style="padding-left: 70px; padding-right: 70px; padding-bottom: 100px;">
                                        <?php echo $product_description ?>
                                    </td>
                                    <td style="padding-left: 70px; padding-right: 70px; padding-bottom: 100px;">
                                        <?php echo $product_name ?>
                                    </td>
                                    <td style="padding-left: 70px; padding-right: 70px; padding-bottom: 100px;">
                                        <form action="cart.php?cart=true" method="post">
                                            <select name="product_quantity" onchange="this.form.submit()">
                                                <?php
                                                // Queries available quantity in database for product, using its product id
                                                $quantity_query = "SELECT quantity FROM products where prodid=$product_id";
                                                $quantity_search = mysqli_query($dlink, $quantity_query);
                                                $product_quantity = mysqli_fetch_array($quantity_search);

                                                // dynamically creates options for the select object based on the quantity of the product in the products database
                                                // @product_quantity - product quantity of the carted product
                                                for ($range = 1; $range <= $product_quantity[0]; $range++) {
                                                    if ($range == $carted_quantity) { ?>
                                                        <option value=<?php echo $range ?> selected><?php echo $range ?></option>
                                                        <?php continue;
                                                    } ?>
                                                    <option value=<?php echo $range ?>><?php echo $range ?></option>
                                                <?php } ?>

                                                <!-- @update_prod - product id of the quantity to be updated when select option for quantity  -->
                                            </select>
                                            <input type="hidden" name="update_prod" value=<?php echo $product_id ?>>
                                        </form>
                                    </td>
                                    <td style="padding-left: 70px; padding-right: 70px; padding-bottom: 100px;">
                                        <?php echo $product_price ?>
                                    </td>
                                    <td style="padding-left: 70px; padding-right: 70px;">
                                    <button type="submit" name="del_prod" value="<?php echo $product_id ?>" style="background-color: red; color: white;">Delete</button>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding-top: 10px; padding-bottom: 70px;">
                                    <strong>TOTAL: </strong>
                                    <?php echo $total_price ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <input style="display: block; margin: 0 auto; padding-top: 10px; padding-bottom: 10px; background-color: yellow;" type="submit" value="Place orders">
                </form>
            </div>
        <?php } ?>
      <!-- end fashion section -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>
